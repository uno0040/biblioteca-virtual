// ignore_for_file: prefer_const_constructors

import 'package:application_muito_foda/Objects/book_model.dart';
import 'package:application_muito_foda/Objects/user_model.dart';
import 'package:application_muito_foda/Pages/main_admin_screen.dart';
import 'package:application_muito_foda/Repositories/book_repository.dart';
import 'package:application_muito_foda/Repositories/user_repository.dart';
import 'package:flutter/material.dart';
import 'package:application_muito_foda/Objects/books.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';

import '../Components/snakbar.dart';

/*
class MyApp extends StatelessWidget {
  @override
  
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CadastroPage(),
    );
  }
}*/

class CadastroPage extends StatefulWidget {
  static const String id = 'CadastroPageState'; // mudar o nome deste tanço

  const CadastroPage({Key? key}) : super(key: key);

  @override
  CadastroPageState createState() => CadastroPageState();
}

class CadastroPageState extends State<CadastroPage> {
  final List<BookObject> bookObjectList = [];

  final TextEditingController _controllerTitle = TextEditingController();
  final TextEditingController _controllerAuthor = TextEditingController();
  final TextEditingController _controllerIllustrator = TextEditingController();
  final TextEditingController _controllerCollection = TextEditingController();
  final TextEditingController _controllerPublisher = TextEditingController();
  final TextEditingController _controllerEdition = TextEditingController();
  final TextEditingController _controllerVolume = TextEditingController();
  final TextEditingController _controllerYear = TextEditingController();
  final TextEditingController _controllerResenha = TextEditingController();
  final TextEditingController _controllerCondition = TextEditingController();
  final TextEditingController _controllerPosition = TextEditingController();
  final TextEditingController _controllerPagesNumber = TextEditingController();
  final TextEditingController _controllerRating= TextEditingController();
  final TextEditingController _controllerLanguage = TextEditingController();
  double ratin = 0.0;
  bool sucesso = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Cadastro de Livros"),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(25),
          child: Column(
            children: [
              SizedBox(height: 20),
              Text(
                "Insira dados do livro abaixo",
              ),
              SizedBox(height: 30),
              TextFormField(
                controller: _controllerTitle,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Título",
                  prefixIcon: const Icon(Icons.menu_book_rounded),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira um título.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(height: 30),
              TextFormField(
                controller: _controllerAuthor,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Autor",
                  prefixIcon: const Icon(Icons.person_outline),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira o autor.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(height: 30),
              TextFormField(
                controller: _controllerIllustrator, // input
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Ilustrador",
                  prefixIcon: const Icon(Icons.architecture),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira o ilustrador.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(height: 30),
              // MUDAR A FIELD DA DATA
              TextFormField(
                controller: _controllerCollection,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Coleção",
                  prefixIcon: const Icon(Icons.collections_bookmark_rounded),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira a coleção.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              //MUDAR O FIELD DA SENHA
              TextFormField(
                controller: _controllerPublisher,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Editora",
                  prefixIcon: const Icon(Icons.public_sharp),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira a editora.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              //MUDAR O FIELD DA SENHA
              TextFormField(
                controller: _controllerEdition,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Edição",
                  prefixIcon: const Icon(Icons.library_books),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira a edição.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              //MUDAR O FIELD DA SENHA
              TextFormField(
                controller: _controllerVolume,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Volume",
                  prefixIcon: const Icon(Icons.view_column_outlined),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira o volume.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              //MUDAR O FIELD DA SENHA
              TextFormField(
                controller: _controllerYear,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Ano",
                  prefixIcon: const Icon(Icons.calendar_month_outlined),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira o ano do livro.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              //MUDAR O FIELD DA SENHA
              TextFormField(
                controller: _controllerResenha,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Resenha",
                  prefixIcon: const Icon(Icons.article),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira a resenha do livro.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              TextFormField(
                controller: _controllerCondition,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Condição",
                  prefixIcon: const Icon(Icons.menu_book_outlined),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira a condição do livro.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              TextFormField(
                controller: _controllerPosition,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Prateleira",
                  prefixIcon: const Icon(Icons.shelves),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira a posição do livro.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              TextFormField(
                controller: _controllerPagesNumber,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Número de páginas",
                  prefixIcon: const Icon(Icons.find_in_page_rounded),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira o número de páginas.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              TextFormField(
                controller: _controllerRating,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Classificação",
                  prefixIcon: const Icon(Icons.star_border_purple500_outlined),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira a classificação do livro.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              SizedBox(
                height: 30,
              ),
              TextFormField(
                controller: _controllerLanguage,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Língua",
                  prefixIcon: const Icon(Icons.language_rounded),
                ),
                // validação de entrada, checar a entrada do input de nome
                validator: (String? value) {
                  if (value == null || value.isEmpty) {
                    return "Por favor insira a língua do livro.";
                  }
                  // TEM QUER COLOCAR UMA CONDIÇÃO DE CHECAR SE O NOME JA EXISTE NO BANCO DE DADOS
                },
              ),
              /*
              SizedBox(height: 30),
              Text(
                "Insira a condição do livro",
              ),
              RatingBar.builder(
                initialRating: rating,
                minRating: 0,
                direction: Axis.horizontal,
                allowHalfRating: true,
                itemCount: 5,
                itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                itemBuilder: (context, _) => Icon(
                  Icons.star,
                  color: Colors.amber,
                ),
                onRatingUpdate: (value) {
                  setState(() {
                    rating = value;
                  });
                },
              ),*/

              SizedBox(
                height: 30,
              ),
              // COLOCAR UM DISABLE CASO OS DADOS NÃO TENHAM SIDO PREENCHIDOS
              ElevatedButton(
                  onPressed: () {
                    cadastraLivro();
                    //Navigator.of(context).pop();
                    Navigator.pushNamed(context, Admin_screen.id);
                    CustomSnackBar.showSuccessSnackBar(context,
                        message: 'Voce cadastrou um livro com sucesso');
                  },
                  child: Text("Cadastrar"))
            ],
          ),
        ),
      ),
    );
  }

  Future<void> cadastraLivro() async {
    String        title = _controllerTitle.text;
    String       author = _controllerAuthor.text;
    String  illustrator = _controllerIllustrator.text;
    String   collection = _controllerCollection.text;
    String    publisher = _controllerPublisher.text;
    String      edition = _controllerEdition.text;
    String       volume = _controllerVolume.text;
    String         year = _controllerYear.text;
    String      resenha = _controllerResenha.text;
    String    condition = _controllerCondition.text;
    String     position = _controllerPosition.text;
    String   pageNumber = _controllerPagesNumber.text;
    String       rating = _controllerRating.text;
    String     language = _controllerLanguage.text;

    // chamada a BookRepository, onde o código do banco de dados esta implementado.
    final bookRepo = Get.put(BookRepository());

    if (title.isNotEmpty        &&
        author.isNotEmpty       &&
        illustrator.isNotEmpty  &&
        collection.isNotEmpty   &&
        publisher.isNotEmpty    &&
        edition.isNotEmpty      &&
        volume.isNotEmpty       &&
        year.isNotEmpty         &&
        resenha.isNotEmpty      &&
        condition.isNotEmpty    &&
        position.isNotEmpty) {

      // BookModel usado para inserção no banco de dados
      // 
      BookModel novoLivro = BookModel(
                title       : title, 
                author      : author, 
                illustrator : illustrator, 
                collection  : collection, 
                publisher   : publisher, 
                edition     : edition, 
                volume      : volume, 
                year        : year, 
                resenha     : resenha,
                lendFlag    : "False",
                condition   : condition,
                position    : position,
                pageNumber  : pageNumber,
                rating      : rating,
                language    : language
                );


      BookObject newBook = BookObject(
        title: title,
        author: author,
        illustrator: illustrator,
        collection: collection,
        publisher: publisher,
        edition: edition,
        volume: volume,
        year: year,
        resenha: resenha,
        rating: ratin,
      );
      await bookRepo.addBook(novoLivro);
      setState(() {
        bookObjectList.add(newBook);
      });
      // Limpar os campos após o cadastro
      _controllerTitle.clear();
      _controllerAuthor.clear();
      _controllerIllustrator.clear();
      _controllerCollection.clear();
      _controllerPublisher.clear();
      _controllerEdition.clear();
      _controllerVolume.clear();
      _controllerYear.clear();
      _controllerResenha.clear();
      _controllerCondition.clear();
      _controllerPagesNumber.clear();
      _controllerRating.clear();
      _controllerLanguage.clear();

      // Exibir um diálogo de sucesso
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Cadastro bem-sucedido'),
            content: Text('Seu livro foi cadastrado com sucesso.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  // Fechar o diálogo
                  Navigator.of(context).pop();
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    } else {
      setState(() {
        sucesso = false;
      });
    }
  }
}
