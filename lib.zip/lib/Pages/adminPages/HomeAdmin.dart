// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:application_muito_foda/Pages/adminPages/sliverSearch_barAdm.dart';
import 'package:flutter/material.dart';

class HomeAdmin extends StatefulWidget {
  static const String id = 'HomeAdmin';

  const HomeAdmin({Key? key}) : super(key: key);

  @override
  HomeAdmin_State createState() => HomeAdmin_State();
}

class HomeAdmin_State extends State<HomeAdmin> {
  int quantidadeUsers = 4;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverPersistentHeader(
            delegate: SliverSearchAppBar(),
            pinned: true,
          ),
        SliverList(
  delegate: SliverChildBuilderDelegate(
    (BuildContext context, int index) {
      if (index < quantidadeUsers) {
        List<List<String>> HistoricoLivros = [
          ['Livro1', 'Livro 2', 'livro 3'],
          ['Livro45', 'livro 56'],
          ['livro 5', 'livro 20'],
          ['livro 47']
          // Adicione mais nomes de arquivos conforme necessário
        ];

        return InkWell(
          onTap: () {
            // Adicione a lógica que você deseja executar ao clicar no ícone de pessoa
            print('Ícone de pessoa clicado para o usuário ${index + 1}');
          },
          child: Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 150,
                  width: 100,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.deepPurple.shade200,
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Icon(
                        Icons.person,
                        size: 50, // Ajuste o tamanho conforme necessário
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      // NOMES DO USUÁRIO VAI AQUI
                      'Nome do Usuário ${index + 1}',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      // HISTÓRICO DE LIVROS
                      'Histórico de Livros:',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black26,
                        fontWeight: FontWeight.w200,
                      ),
                    ),
                    SizedBox(height: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: HistoricoLivros[index]
                          .map((livro) => Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    livro,
                                    style: TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w200,
                                      color: Colors.grey.shade800,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                ],
                              ))
                          .toList(),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      } else {
        return Container();
      }
    },
    childCount: quantidadeUsers,
  ),
),



        ],
      ),
    );
  }
}
